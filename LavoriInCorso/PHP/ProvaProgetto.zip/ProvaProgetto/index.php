<?php
session_start();
?>

<html>
<head>
<title>HomePage</title>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body{
height: 200px;
background: radial-gradient(circle farthest-corner at 100px 50px, #FBF2EB, cyan);
}
/* Style the navigation bar */
.navbar {
  width: 100%;
  background-color:#808080;
  overflow: auto;
  margin-top:-7.52px;
}

/* Navbar links */
.navbar a {
  float: left;
  text-align: center;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

/* Navbar links on mouse-over */
.navbar a:hover {
  background-color: #000080;
}

/* Current/active navbar link */
.active {
  background-color: #808080;
}

/* Add responsiveness - will automatically display the navbar vertically instead of horizontally on screens less than 500 pixels */
@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
body{
    background-color: white;
}
p{
    color:#000080;
    text-align:center;
}

</style>
</head>


<body>
    <form id="formHomePage"method="POST">

<!-- Load an icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="navbar">
  <a class="active" href="index.php"><i class="fa fa-fw fa-home"></i> Home</a>
  <a href="visualizzaDati.php"><i class="fas fa-school"></i> Dati Scolastici</a>
</div>

<div class="divBox">
<p>In questa pagina andremo a dare la possibilità all'utente di visualizzare i dati relativi a tutte le scuole italiane.
Tramite la navbar in alto alla pagina si offre la possibilità di navigare all'interno delle pagine e scegliere che cosa si prefeirsce fare.
Se andremo a selezionare la voce "Dati Scolastici",verremo reindirizzati in un altra pagina dove ci verrano mostrati i dati relativi alle scuole.
Una volta selezionata la voce "Dati Scolastici", sulla navbar potremo vedere una nuova voce chiamata "Scarica"che,se cliccata,permetterà di scaricare i dati relativi al database.</p>
</div>

</body>
</html>