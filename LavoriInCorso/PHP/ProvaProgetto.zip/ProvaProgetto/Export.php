<?php  
      //export.php  
 
      $connect = mysqli_connect("localhost", "root", "", "dbprogetto");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('ANNOSCOLASTICO','AREAGEOGRAFICA','REGIONE','PROVINCIA','CODICEISTITUTORIFERIMENTO','DENOMINAZIONEISTITUTORIFERIMENTO','CODICESCUOLA','DENOMINAZIONESCUOLA','INDIRIZZOSCUOLA','CAPSCUOLA','CODICECOMUNESCUOLA','DESCRIZIONECOMUNE','DESCRIZIONECARATTERISTICASCUOLA','DESCRIZIONETIPOLOGIAGRADOISTRUZIONESCUOLA','INDICAZIONESEDEDIRETTIVO','INDICAZIONESEDEOMNICOMPRENSIVO','INDIRIZZOEMAILSCUOLA','INDIRIZZOPECSCUOLA','SITOWEBSCUOLA','SEDESCOLASTICA'));  
      $query = "SELECT * from prova";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
  
 ?>  

