<?php

require("Connection.php");

$query="SELECT * FROM prova";

if(!$result=mysqli_query($con,$query)){
    exit(mysqli_error($con));
}

$users=array();
if(mysqli_num_rows($results)>0){
    while($row=mysqli_fetch_assoc($results)){
        $users[]=$row;
    }
}

header('Content-Type: text/csv;charset=utf-8');
header('Content-Disposition: attachment;filename=Dati.csv');
$output=fopen('php://output','w');
fputcsv($output,array('NO','ANNOSCOLASTICO','AREAGEOGRAFICA','REGIONE','PROVINCIA','CODICEISTITUTORIFERIMENTO','DENOMINAZIONEISTITUTORIFERIMENTO','CODICESCUOLA','DENOMINAZIONESCUOLA','INDIRIZZOSCUOLA','CAPSCUOLA','CODICECOMUNESCUOLA','DESCRIZIONECOMUNE','DESCRIZIONECARATTERISTICASCUOLA','DESCRIZIONETIPOLOGIAGRADOISTRUZIONESCUOLA','INDICAZIONESEDEDIRETTIVO','INDICAZIONESEDEOMNICOMPRENSIVO','INDIRIZZOEMAILSCUOLA','INDIRIZZOPECSCUOLA','SITOWEBSCUOLA','SEDESCOLASTICA'));


if(count($users)>0){
    foreach($users as $row){
        fputcsv($output,$row);
    }
}