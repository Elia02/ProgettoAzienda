<!DOCTYPE html>
<html>
<head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>

/* Style the navigation bar */
.navbar {
  width: 222.7%;
  background-color:#808080;
  overflow: auto;
  margin-top:-7.52px;
}

/* Navbar links */
.navbar a {
  float: left;
  text-align: center;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

/* Navbar links on mouse-over */
.navbar a:hover {
  background-color: #000080;
}

/* Current/active navbar link */
.active {
  background-color: #808080;
}

/* Add responsiveness - will automatically display the navbar vertically instead of horizontally on screens less than 500 pixels */
@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}


table {
    border: 1px solid black;
    width:80%;
    text-align:center;
    margin:auto;
    height:150px;
}
th,td{
    border: 1px solid black;
}


</style>
</head>


<body>
<!-- Load an icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="navbar">
  <a class="active" href="index.php"><i class="fa fa-fw fa-home"></i> Home</a>
  <a href="visualizzaDati.php"><i class="fas fa-school"></i> Dati Scolastici</a>
  <a href="Export.php"><i class="fas fa-file-export"></i> Scarica</a>
</div>
</body>
</html>

<?php
$conn = new mysqli("localhost","root","","dbProgetto");

$risultatiperpage=25;

if(isset($_GET['page'])){
  if($_GET['page']>1){
    $start=($_GET['page']-1)*$risultatiperpage;
  }else{
  $start=0;
}
}else{
  $start=0;
}
$sql=$conn->query("SELECT COUNT(*) as conteggio from prova");
$array=$sql->fetch_assoc();
$totalerighe=$array['conteggio'];
$totalepagine=ceil($totalerighe/$risultatiperpage);
$query=$conn->query("SELECT * FROM prova LIMIT ".$start.",".$risultatiperpage);
?>

<html>
<head>
</head>
<body>
<table>
<thead>
<th>
Id
</th>
<th>
Anno Scolastico
</th>
<th>
Area Geografica
</th>
<th>
REGIONE
</th>
<th>
PROVINCIA
</th>
<th>
CODICEISTITUTORIFERIMENTO
</th>
<th>
DENOMINAZIONEISTITUTORIFERIMENTO
</th>
<th>
CODICESCUOLA
</th>
<th>
DENOMINAZIONESCUOLA
</th>
<th>
INDIRIZZOSCUOLA
</th>
<th>
CAPSCUOLA
</th>
<th>
CODICECOMUNESCUOLA
</th>
<th>
DESCRIZIONECOMUNE
</th>
<th>
DESCRIZIONECARATTERISTICASCUOLA
</th>
<th>
DESCRIZIONETIPOLOGIAGRADOISTRUZIONESCUOLA
</th>
<th>
INDICAZIONESEDEDIRETTIVO
</th>
<th>
INDICAZIONESEDEOMNICOMPRENSIVO
</th>
<th>
INDIRIZZOEMAILSCUOLA
</th>
<th>
INDIRIZZOPECSCUOLA
</th>
<th>
SITOWEBSCUOLA
</th>
<th>
SEDESCOLASTICA
</th>
</thead>
<tbody>
<?php
  while($riga=$query->fetch_assoc())
  echo "<tr><td>".$riga['id']."</td><td>".$riga['ANNOSCOLASTICO']."</td><td>".$riga['AREAGEOGRAFICA']."</td><td>".$riga['REGIONE']."</td><td>".$riga['PROVINCIA']."</td><td>".$riga['CODICEISTITUTORIFERIMENTO']."</td><td>".$riga['DENOMINAZIONEISTITUTORIFERIMENTO']."</td><td>".$riga['CODICESCUOLA']."</td><td>".$riga['DENOMINAZIONESCUOLA']."</td><td>".$riga['INDIRIZZOSCUOLA']."</td><td>".$riga['CAPSCUOLA']."</td><td>".$riga['CODICECOMUNESCUOLA']."</td><td>".$riga['DESCRIZIONECOMUNE']."</td><td>".$riga['DESCRIZIONECARATTERISTICASCUOLA']."</td><td>".$riga['DESCRIZIONETIPOLOGIAGRADOISTRUZIONESCUOLA']."</td><td>".$riga['INDICAZIONESEDEDIRETTIVO']."</td><td>".$riga['INDICAZIONESEDEOMNICOMPRENSIVO']."</td><td>".$riga['INDIRIZZOEMAILSCUOLA']."</td><td>".$riga['INDIRIZZOPECSCUOLA']."</td><td>".$riga['SITOWEBSCUOLA']."</td><td>".$riga['SEDESCOLASTICA']."</td></tr>";
  ?>
  </tbody>
  </table>
  <ul>
  <?php
    for($x=1;$x<=$totalepagine;$x++){
      echo "<li><a href='./visualizzaDati.php?page=".$x."'>".$x."</a></li>";
    }
  ?>
  </body>
  </html>